//
//  GameViewController.swift
//  piano
//
//  Created by Andrew Suster on 5/5/23.
//
import AVFoundation
import UIKit
import QuartzCore
import SceneKit
import SwiftUI
import SpriteKit


class CustomButton: SKSpriteNode {
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let scene = self.scene else { return }
        
        for touch in touches {
            let location = touch.location(in: scene)
            
            if self.contains(location) {
                // Button is tapped
                HomeTapped()
            }
        }
    }
    private func HomeTapped() {
        print("Home tapped")
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let nextViewController = storyboard.instantiateViewController(withIdentifier: "homebutton") as! StartViewController

        
        
        nextViewController.modalPresentationStyle = .fullScreen
        if let rootViewController = scene?.view?.window?.rootViewController {
            rootViewController.present(nextViewController, animated: true, completion: nil)
        
        }

    }
}

class GameViewController: UIViewController {
    
 
    let buttonLabel = SKLabelNode(text: "")
    let imageNodeThing = SKSpriteNode(imageNamed: "imageName")
    var backgroundNode = SKSpriteNode(color: SKColor.red, size: CGSize(width: 5000, height: 5000))
    var yesbackgroundNode = SKSpriteNode(color: SKColor.green, size: CGSize(width: 5000, height: 5000))
    var wrongNode = SKLabelNode(text: "")
    var correctNode = SKLabelNode(text: "")
    var textNode = SKLabelNode(text: "Play C")
    var sceneView: SCNView!
    var newsong = "Play: (sequence)"
    @State var wronganswer = true
    let sequence1 = ["Moog+Sub37-013"]
    let sequence1e = ["Moog+Sub37-001"]
    let sequence1a = ["Moog+Sub37-025"]
    let sequence1ea = ["Moog+Sub37-037"]
    let sequence2 = ["Moog+Sub37-020"]
    let sequence2e = ["Moog+Sub37-008"]
    let sequence2a = ["Moog+Sub37-032"]
    let sequence3 = ["Moog+Sub37-023"]
    let sequence3e = ["Moog+Sub37-035"]
    let sequence3a = ["Moog+Sub37-011"]
    let sequence4 = ["Moog+Sub37-016"]
    let sequence4e = ["Moog+Sub37-028"]
    let sequence4a = ["Moog+Sub37-04"]
    let sequence5 = ["Moog+Sub37-013","Moog+Sub37-015","Moog+Sub37-017","Moog+Sub37-018","Moog+Sub37-020","Moog+Sub37-022","Moog+Sub37-024","Moog+Sub37-025"]
    let sequence5e = ["Moog+Sub37-001","Moog+Sub37-003","Moog+Sub37-005","Moog+Sub37-006","Moog+Sub37-008","Moog+Sub37-010","Moog+Sub37-012","Moog+Sub37-013"]
    let sequence5a = ["Moog+Sub37-025","Moog+Sub37-027","Moog+Sub37-029","Moog+Sub37-030","Moog+Sub37-032","Moog+Sub37-034","Moog+Sub37-036","Moog+Sub37-037"]
    let sequence6 = ["Moog+Sub37-022","Moog+Sub37-024","Moog+Sub37-025","Moog+Sub37-027","Moog+Sub37-029","Moog+Sub37-030","Moog+Sub37-032","Moog+Sub37-034"]
    let sequence6e = ["Moog+Sub37-010","Moog+Sub37-012","Moog+Sub37-013","Moog+Sub37-015","Moog+Sub37-017","Moog+Sub37-018","Moog+Sub37-020","Moog+Sub37-022"]
    let sequence7 = ["Moog+Sub37-014","Moog+Sub37-016","Moog+Sub37-017","Moog+Sub37-019","Moog+Sub37-021","Moog+Sub37-022","Moog+Sub37-024","Moog+Sub37-026"]
    let sequence7e = ["Moog+Sub37-002","Moog+Sub37-004","Moog+Sub37-005","Moog+Sub37-007","Moog+Sub37-009","Moog+Sub37-010","Moog+Sub37-012","Moog+Sub37-014"]
    let sequence8 = ["Moog+Sub37-017","Moog+Sub37-020","Moog+Sub37-022","Moog+Sub37-024","Moog+Sub37-027","Moog+Sub37-029"]
    let sequence8e = ["Moog+Sub37-005","Moog+Sub37-008","Moog+Sub37-010","Moog+Sub37-012","Moog+Sub37-015","Moog+Sub37-017"]
    let sequence9 = ["Moog+Sub37-016","Moog+Sub37-017","Moog+Sub37-019","Moog+Sub37-021","Moog+Sub37-022","Moog+Sub37-024","Moog+Sub37-026","Moog+Sub37-028"]
    let sequence9e = ["Moog+Sub37-004","Moog+Sub37-005","Moog+Sub37-007","Moog+Sub37-009","Moog+Sub37-010","Moog+Sub37-012","Moog+Sub37-014","Moog+Sub37-016"]
    var sequenceIndex1 = 0
    var sequenceIndex2 = 0
    var sequenceIndex3 = 0
    var sequenceIndex4 = 0
    var sequenceIndex5 = 0
    var sequenceIndex6 = 0
    var sequenceIndex7 = 0
    var sequenceIndex8 = 0
    var sequenceIndex9 = 0
    var currentSequence = 1
    var audioPlayer: AVAudioPlayer?
    var myCondition = false
   
    @objc func HomeTapped() {
        print("hometapped")

        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        
        

                let nextViewController = storyBoard.instantiateViewController(withIdentifier: "homebutton") as! StartViewController

        nextViewController.modalPresentationStyle = .fullScreen
                self.present(nextViewController, animated:true, completion:nil)
    }


    @objc
    func handleTap(_ gestureRecognize: UIGestureRecognizer) {
        
        
        print("handling tap!!!")
        
        let scene = SCNScene(named: "art.scnassets/ship.scn")!
        let scnView = self.view as! SCNView
        let p = gestureRecognize.location(in: scnView)
        let hitResults = scnView.hitTest(p, options: [:])
        if hitResults.count > 0 {
            
            let result = hitResults[0]
            if let nodeName = result.node.name, !nodeName.isEmpty {
                
                let soundFiles = [
                    "Moog+Sub37-001": "C2.mp3",
                    "Moog+Sub37-002": "Db2.mp3",
                    "Moog+Sub37-003": "D2.mp3",
                    "Moog+Sub37-004": "Eb2.mp3",
                    "Moog+Sub37-005": "E2.mp3",
                    "Moog+Sub37-006": "F2.mp3",
                    "Moog+Sub37-007": "Gb2.mp3",
                    "Moog+Sub37-008": "G2.mp3",
                    "Moog+Sub37-009": "Ab2.mp3",
                    "Moog+Sub37-010": "A2.mp3",
                    "Moog+Sub37-011": "Bb2.mp3",
                    "Moog+Sub37-012": "B2.mp3",
                    "Moog+Sub37-013": "C3.mp3",
                    "Moog+Sub37-014": "Db3.mp3",
                    "Moog+Sub37-015": "D3.mp3",
                    "Moog+Sub37-016": "Eb3.mp3",
                    "Moog+Sub37-017": "E3.mp3",
                    "Moog+Sub37-018": "F3.mp3",
                    "Moog+Sub37-019": "Gb3.mp3",
                    "Moog+Sub37-020": "G3.mp3",
                    "Moog+Sub37-021": "Ab3.mp3",
                    "Moog+Sub37-022": "A3.mp3",
                    "Moog+Sub37-023": "Bb3.mp3",
                    "Moog+Sub37-024": "B3.mp3",
                    "Moog+Sub37-025": "C4.mp3",
                    "Moog+Sub37-026": "Db4.mp3",
                    "Moog+Sub37-027": "D4.mp3",
                    "Moog+Sub37-028": "Eb4.mp3",
                    "Moog+Sub37-029": "E4.mp3",
                    "Moog+Sub37-030": "F4.mp3",
                    "Moog+Sub37-031": "Gb4.mp3",
                    "Moog+Sub37-032": "G4.mp3",
                    "Moog+Sub37-033": "Ab4.mp3",
                    "Moog+Sub37-034": "A4.mp3",
                    "Moog+Sub37-035": "Bb4.mp3",
                    "Moog+Sub37-036": "B4.mp3",
                    "Moog+Sub37-037": "C5.mp3",
                    
                ]
                
                let soundFileName = soundFiles[nodeName] ?? ""
                if let soundFile = soundFiles[nodeName], let soundURL = Bundle.main.url(forResource: soundFile, withExtension: nil) {
                    do {
                        
                        audioPlayer = try AVAudioPlayer(contentsOf: soundURL)
                        audioPlayer?.prepareToPlay()
                        audioPlayer?.play()
                    } catch {
                        print("Failed to play sound for node: \(nodeName), error: \(error.localizedDescription)")
                    }
                } else {
                    print("Sound file not found for node: \(nodeName)")
                }
                
            }
            
            if let nodeName = result.node.name, nodeName == "box11"  {
                
                HomeTapped()
                let material = result.node.geometry!.firstMaterial!
                
                SCNTransaction.begin()
                SCNTransaction.animationDuration = 0.2
                SCNTransaction.completionBlock = {
                    SCNTransaction.begin()
                    SCNTransaction.animationDuration = 0.5
                    material.emission.contents = UIColor.black
                    let upAnimation = CABasicAnimation(keyPath: "position.y")
                    upAnimation.fromValue = result.node.position.y - 0.1
                    upAnimation.toValue = result.node.position.y
                    
                    result.node.addAnimation(upAnimation, forKey: "moveUp")
                    
                    
                    SCNTransaction.commit()
                }
                
                material.emission.contents = UIColor.red
                let downAnimation = CABasicAnimation(keyPath: "position.y")
                downAnimation.fromValue = result.node.position.y
                downAnimation.toValue = result.node.position.y - 1
                material.emission.contents = UIColor.black
                result.node.addAnimation(downAnimation, forKey: "moveDown")
                SCNTransaction.commit()
            }
            
            if let nodeName = result.node.name, nodeName == "Moog+Sub37-001" || nodeName == "Moog+Sub37-002" || nodeName == "Moog+Sub37-003" || nodeName == "Moog+Sub37-004" || nodeName == "Moog+Sub37-005" || nodeName == "Moog+Sub37-006" || nodeName == "Moog+Sub37-007" || nodeName == "Moog+Sub37-008" || nodeName == "Moog+Sub37-009" || nodeName == "Moog+Sub37-010" || nodeName == "Moog+Sub37-011" || nodeName == "Moog+Sub37-012" || nodeName == "Moog+Sub37-013" || nodeName == "Moog+Sub37-014" || nodeName == "Moog+Sub37-015" || nodeName == "Moog+Sub37-016" || nodeName == "Moog+Sub37-017" || nodeName == "Moog+Sub37-018" || nodeName == "Moog+Sub37-019" || nodeName == "Moog+Sub37-020" || nodeName == "Moog+Sub37-021" || nodeName == "Moog+Sub37-022" || nodeName == "Moog+Sub37-023" || nodeName == "Moog+Sub37-024" || nodeName == "Moog+Sub37-025" || nodeName == "Moog+Sub37-026" || nodeName == "Moog+Sub37-027" || nodeName == "Moog+Sub37-028" || nodeName == "Moog+Sub37-029" || nodeName == "Moog+Sub37-030" || nodeName == "Moog+Sub37-031" || nodeName == "Moog+Sub37-032" || nodeName == "Moog+Sub37-033" || nodeName == "Moog+Sub37-034" || nodeName == "Moog+Sub37-035" || nodeName == "Moog+Sub37-036" || nodeName == "Moog+Sub37-037"  {
                
                let material = result.node.geometry!.firstMaterial!
                
                SCNTransaction.begin()
                SCNTransaction.animationDuration = 0.2
                SCNTransaction.completionBlock = {
                    SCNTransaction.begin()
                    SCNTransaction.animationDuration = 0.5
                    material.emission.contents = UIColor.black
                    let upAnimation = CABasicAnimation(keyPath: "position.y")
                    upAnimation.fromValue = result.node.position.y - 0.1
                    upAnimation.toValue = result.node.position.y
                    
                    result.node.addAnimation(upAnimation, forKey: "moveUp")
                    
                    
                    SCNTransaction.commit()
                }
                
                material.emission.contents = UIColor.red
                let downAnimation = CABasicAnimation(keyPath: "position.y")
                downAnimation.fromValue = result.node.position.y
                downAnimation.toValue = result.node.position.y - 1
                material.emission.contents = UIColor.black
                result.node.addAnimation(downAnimation, forKey: "moveDown")
                SCNTransaction.commit()
            }
            
            
            
            
            if currentSequence == 1 {
                
                
                
                if let nodeName = result.node.name{
                    if nodeName == "box11" {
                        
                    }
                    
                    else if nodeName == sequence1[sequenceIndex1]||nodeName == sequence1e[sequenceIndex1]||nodeName == sequence1a[sequenceIndex1]||nodeName == sequence1ea[sequenceIndex1] {
                        
                        sequenceIndex1 += 1
                        
                        if sequenceIndex1 >= sequence1.count {
                            // The user completed the sequence
                            textNode.text = ""
                            
                            
                            print("Sequence 1 complete!")
                            
                            
                            yesbackgroundNode.position = CGPoint(x: 100, y: 100)
                            correctNode.text = "CORRECT"
                            
                            // Wait for 3 seconds using a DispatchQueue
                            DispatchQueue.main.asyncAfter(deadline: .now() + 2) { [self] in
                                // Set the text to an empty string
                                correctNode.text = ""
                                yesbackgroundNode.position = CGPoint(x: -10000, y: -10000)
                                textNode.text = "Play G"
                            }
                            
                            
                            
                            
                            
                            
                            let woonoise = [
                                "woo-105117"
                            ]
                            let woonoisename = woonoise[0]
                            let woofile = woonoise[0]
                            let wooURL = Bundle.main.url(forResource: woofile, withExtension: "mp3")
                            
                            if woofile == woonoise[0] {
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) {
                                    
                                    do {
                                        self.audioPlayer = try AVAudioPlayer(contentsOf: wooURL!)
                                        self.audioPlayer?.prepareToPlay()
                                        self.audioPlayer?.play()
                                        
                                    }catch {
                                        print("Failed to play sound for node: \("the thing")")
                                    }
                                }
                            } else {
                                print("Sound file not found for node: \("the thing")")
                            }
                            
                            print(currentSequence)
                            sequenceIndex1 = 0  // Reset the sequence for the next round
                            currentSequence = 2
                            print(currentSequence)
                            
                        }
                    } else {
                


                   
                        if let physicsBody = result.node.physicsBody {
                            physicsBody.applyForce(SCNVector3(x: 2, y: 0, z:2), asImpulse: true)
                        }
                       
                           
                        
                        SCNTransaction.commit()
                        // The user tapped the wrong node or the sequence is not complete
                        print("Incorrect sequence!")
                        myCondition = true
                        // Set the initial text
                        sequenceIndex1 = 0
                        backgroundNode.position = CGPoint(x: 800, y: 800)
                        wrongNode.text = "WRONG"
                        textNode.text = ""

                        // Wait for 3 seconds using a DispatchQueue
                        DispatchQueue.main.asyncAfter(deadline: .now() + 5.5) { [self] in
                            // Set the text to an empty string
                            backgroundNode.position = CGPoint(x: -10000, y: -10000)
                            wrongNode.text = ""
                            textNode.text = "Play C"
                        }



                        let deathnoise = [
                            "mixkit-cartoon-laugh-voice-2882"
                        ]

                        let deathnoisename = deathnoise[0]
                        let deathfile = deathnoise[0]
                        let deathURL = Bundle.main.url(forResource: deathfile, withExtension: "wav")
                        if deathfile == deathnoise[0] {
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) {
                                do {

                                    self.audioPlayer = try AVAudioPlayer(contentsOf: deathURL!)
                                    self.audioPlayer?.prepareToPlay()
                                    self.audioPlayer?.play()
                                } catch {
                                    print("Failed to play sound for node: \("the thing")")
                                }
                            }
                        }else {
                            print("Sound file not found for node: \("the thing")")
                        }

                        sequenceIndex1 = 0
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) {

                        }
                    }
                }
            } else if currentSequence == 2 {
                
                if let nodeName = result.node.name{
                    if nodeName == "box11" {
                        
                    }
                    
                    else if nodeName == result.node.name, nodeName == sequence2[sequenceIndex2]||nodeName == sequence2e[sequenceIndex2]||nodeName == sequence2a[sequenceIndex2] {
                        
                        sequenceIndex2 += 1
                        
                        if sequenceIndex2 >= sequence2.count {
                            // The user completed the sequence
                            textNode.text = ""
                            
                            
                            print("Sequence 2 complete!")
                            
                            
                            yesbackgroundNode.position = CGPoint(x: 100, y: 100)
                            correctNode.text = "CORRECT"
                            
                            // Wait for 3 seconds using a DispatchQueue
                            DispatchQueue.main.asyncAfter(deadline: .now() + 2) { [self] in
                                // Set the text to an empty string
                                correctNode.text = ""
                                yesbackgroundNode.position = CGPoint(x: -10000, y: -10000)
                                textNode.text = "Play Bb"
                            }
                            
                            
                            
                            
                            
                            
                            let woonoise = [
                                "woo-105117"
                            ]
                            let woonoisename = woonoise[0]
                            let woofile = woonoise[0]
                            let wooURL = Bundle.main.url(forResource: woofile, withExtension: "mp3")
                            
                            if woofile == woonoise[0] {
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) {
                                    
                                    do {
                                        self.audioPlayer = try AVAudioPlayer(contentsOf: wooURL!)
                                        self.audioPlayer?.prepareToPlay()
                                        self.audioPlayer?.play()
                                        
                                    }catch {
                                        print("Failed to play sound for node: \("the thing")")
                                    }
                                }
                            } else {
                                print("Sound file not found for node: \("the thing")")
                            }
                            
                            print(currentSequence)
                            sequenceIndex1 = 0  // Reset the sequence for the next round
                            currentSequence = 3
                            print(currentSequence)
                            
                        }
                    } else {
                        // The user tapped the wrong node or the sequence is not complete
                        print("Incorrect sequence!")
                        myCondition = true
                        // Set the initial text
                        sequenceIndex2 = 0
                        backgroundNode.position = CGPoint(x: 100, y: 100)
                        wrongNode.text = "WRONG"
                        textNode.text = ""
                        
                        // Wait for 3 seconds using a DispatchQueue
                        DispatchQueue.main.asyncAfter(deadline: .now() + 5.5) { [self] in
                            // Set the text to an empty string
                            backgroundNode.position = CGPoint(x: -10000, y: -10000)
                            wrongNode.text = ""
                            textNode.text = "Play G"
                        }
                        
                        
                        
                        let deathnoise = [
                            "mixkit-cartoon-laugh-voice-2882"
                        ]
                        
                        let deathnoisename = deathnoise[0]
                        let deathfile = deathnoise[0]
                        let deathURL = Bundle.main.url(forResource: deathfile, withExtension: "wav")
                        if deathfile == deathnoise[0] {
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) {
                                do {
                                    
                                    self.audioPlayer = try AVAudioPlayer(contentsOf: deathURL!)
                                    self.audioPlayer?.prepareToPlay()
                                    self.audioPlayer?.play()
                                } catch {
                                    print("Failed to play sound for node: \("the thing")")
                                }
                            }
                        }else {
                            print("Sound file not found for node: \("the thing")")
                        }
                        
                        sequenceIndex2 = 0
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) {
                            
                        }
                    }
                }
            }else if currentSequence == 3 {
                
                if let nodeName = result.node.name{
                    if nodeName == "box11" {
                        
                    }
                    
                    else if nodeName == result.node.name, nodeName == sequence3[sequenceIndex3]||nodeName == sequence3e[sequenceIndex3]||nodeName == sequence3a[sequenceIndex3] {
                        // The user tapped the correct node in the sequence
                        sequenceIndex3 += 1
                        
                        if sequenceIndex3 >= sequence3.count {
                            // The user completed the sequence
                            textNode.text = ""
                            
                            
                            print("Sequence 3 complete!")
                            
                            
                            yesbackgroundNode.position = CGPoint(x: 100, y: 100)
                            correctNode.text = "CORRECT"
                            
                            // Wait for 3 seconds using a DispatchQueue
                            DispatchQueue.main.asyncAfter(deadline: .now() + 2) { [self] in
                                // Set the text to an empty string
                                correctNode.text = ""
                                yesbackgroundNode.position = CGPoint(x: -10000, y: -10000)
                                textNode.text = "Play Eb"
                            }
                            
                            
                            
                            
                            
                            
                            let woonoise = [
                                "woo-105117"
                            ]
                            let woonoisename = woonoise[0]
                            let woofile = woonoise[0]
                            let wooURL = Bundle.main.url(forResource: woofile, withExtension: "mp3")
                            
                            if woofile == woonoise[0] {
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) {
                                    
                                    do {
                                        self.audioPlayer = try AVAudioPlayer(contentsOf: wooURL!)
                                        self.audioPlayer?.prepareToPlay()
                                        self.audioPlayer?.play()
                                        
                                    }catch {
                                        print("Failed to play sound for node: \("the thing")")
                                    }
                                }
                            } else {
                                print("Sound file not found for node: \("the thing")")
                            }
                            
                            print(currentSequence)
                            sequenceIndex3 = 0  // Reset the sequence for the next round
                            currentSequence = 4
                            print(currentSequence)
                            
                        }
                    } else {
                        // The user tapped the wrong node or the sequence is not complete
                        print("Incorrect sequence!")
                        myCondition = true
                        // Set the initial text
                        sequenceIndex1 = 0
                        backgroundNode.position = CGPoint(x: 100, y: 100)
                        wrongNode.text = "WRONG"
                        textNode.text = ""
                        
                        // Wait for 3 seconds using a DispatchQueue
                        DispatchQueue.main.asyncAfter(deadline: .now() + 5.5) { [self] in
                            // Set the text to an empty string
                            backgroundNode.position = CGPoint(x: -10000, y: -10000)
                            wrongNode.text = ""
                            textNode.text = "Play Bb"
                        }
                        
                        
                        
                        let deathnoise = [
                            "mixkit-cartoon-laugh-voice-2882"
                        ]
                        
                        let deathnoisename = deathnoise[0]
                        let deathfile = deathnoise[0]
                        let deathURL = Bundle.main.url(forResource: deathfile, withExtension: "wav")
                        if deathfile == deathnoise[0] {
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) {
                                do {
                                    
                                    self.audioPlayer = try AVAudioPlayer(contentsOf: deathURL!)
                                    self.audioPlayer?.prepareToPlay()
                                    self.audioPlayer?.play()
                                } catch {
                                    print("Failed to play sound for node: \("the thing")")
                                }
                            }
                        }else {
                            print("Sound file not found for node: \("the thing")")
                        }
                        
                        sequenceIndex3 = 0
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) {
                            
                        }
                    }
                }
            }else if currentSequence == 4 {
                
                if let nodeName = result.node.name{
                    if nodeName == "box11" {
                        
                    }
                    
                    else if nodeName == result.node.name, nodeName == sequence4[sequenceIndex4]||nodeName == sequence4e[sequenceIndex4]||nodeName == sequence4a[sequenceIndex4] {
                        // The user tapped the correct node in the sequence
                        sequenceIndex4 += 1
                        
                        if sequenceIndex4 >= sequence4.count {
                            // The user completed the sequence
                            textNode.text = ""
                            
                            
                            print("Sequence 4 complete!")
                            
                            
                            yesbackgroundNode.position = CGPoint(x: 100, y: 100)
                            correctNode.text = "CORRECT"
                            
                            // Wait for 3 seconds using a DispatchQueue
                            DispatchQueue.main.asyncAfter(deadline: .now() + 2) { [self] in
                                // Set the text to an empty string
                                correctNode.text = ""
                                yesbackgroundNode.position = CGPoint(x: -10000, y: -10000)
                                textNode.text = "Play Cmaj"
                            }
                            
                            
                            
                            
                            
                            
                            let woonoise = [
                                "woo-105117"
                            ]
                            let woonoisename = woonoise[0]
                            let woofile = woonoise[0]
                            let wooURL = Bundle.main.url(forResource: woofile, withExtension: "mp3")
                            
                            if woofile == woonoise[0] {
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) {
                                    
                                    do {
                                        self.audioPlayer = try AVAudioPlayer(contentsOf: wooURL!)
                                        self.audioPlayer?.prepareToPlay()
                                        self.audioPlayer?.play()
                                        
                                    }catch {
                                        print("Failed to play sound for node: \("the thing")")
                                    }
                                }
                            } else {
                                print("Sound file not found for node: \("the thing")")
                            }
                            
                            print(currentSequence)
                            sequenceIndex4 = 0  // Reset the sequence for the next round
                            currentSequence = 5
                            print(currentSequence)
                            
                        }
                    } else {
                        // The user tapped the wrong node or the sequence is not complete
                        print("Incorrect sequence!")
                        myCondition = true
                        // Set the initial text
                        sequenceIndex4 = 0
                        backgroundNode.position = CGPoint(x: 100, y: 100)
                        wrongNode.text = "WRONG"
                        textNode.text = ""
                        
                        // Wait for 3 seconds using a DispatchQueue
                        DispatchQueue.main.asyncAfter(deadline: .now() + 5.5) { [self] in
                            // Set the text to an empty string
                            backgroundNode.position = CGPoint(x: -10000, y: -10000)
                            wrongNode.text = ""
                            textNode.text = "Play Eb"
                        }
                        
                        
                        
                        let deathnoise = [
                            "mixkit-cartoon-laugh-voice-2882"
                        ]
                        
                        let deathnoisename = deathnoise[0]
                        let deathfile = deathnoise[0]
                        let deathURL = Bundle.main.url(forResource: deathfile, withExtension: "wav")
                        if deathfile == deathnoise[0] {
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) {
                                do {
                                    
                                    self.audioPlayer = try AVAudioPlayer(contentsOf: deathURL!)
                                    self.audioPlayer?.prepareToPlay()
                                    self.audioPlayer?.play()
                                } catch {
                                    print("Failed to play sound for node: \("the thing")")
                                }
                            }
                        }else {
                            print("Sound file not found for node: \("the thing")")
                        }
                        
                        sequenceIndex4 = 0
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) {
                            
                        }
                    }
                }
            }
            else if currentSequence == 5 {
                
                if let nodeName = result.node.name{
                    if nodeName == "box11" {
                        
                    }
                    
                    else if nodeName == result.node.name, nodeName == sequence5[sequenceIndex5]||nodeName == sequence5e[sequenceIndex5]||nodeName == sequence5a[sequenceIndex5] {
                        // The user tapped the correct node in the sequence
                        sequenceIndex5 += 1
                        
                        if sequenceIndex5 >= sequence5.count {
                            // The user completed the sequence
                            textNode.text = ""
                            
                            
                            print("Sequence 5 complete!")
                            
                            
                            yesbackgroundNode.position = CGPoint(x: 100, y: 100)
                            correctNode.text = "CORRECT"
                            
                            // Wait for 3 seconds using a DispatchQueue
                            DispatchQueue.main.asyncAfter(deadline: .now() + 2) { [self] in
                                // Set the text to an empty string
                                correctNode.text = ""
                                yesbackgroundNode.position = CGPoint(x: -10000, y: -10000)
                                textNode.text = "Play Aminor Scale"
                            }
                            
                            
                            
                            
                            
                            
                            let woonoise = [
                                "woo-105117"
                            ]
                            let woonoisename = woonoise[0]
                            let woofile = woonoise[0]
                            let wooURL = Bundle.main.url(forResource: woofile, withExtension: "mp3")
                            
                            if woofile == woonoise[0] {
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) {
                                    
                                    do {
                                        self.audioPlayer = try AVAudioPlayer(contentsOf: wooURL!)
                                        self.audioPlayer?.prepareToPlay()
                                        self.audioPlayer?.play()
                                        
                                    }catch {
                                        print("Failed to play sound for node: \("the thing")")
                                    }
                                }
                            } else {
                                print("Sound file not found for node: \("the thing")")
                            }
                            
                            print(currentSequence)
                            sequenceIndex5 = 0  // Reset the sequence for the next round
                            currentSequence = 6
                            print(currentSequence)
                            
                        }
                    } else {
                        // The user tapped the wrong node or the sequence is not complete
                        print("Incorrect sequence!")
                        myCondition = true
                        // Set the initial text
                        sequenceIndex5 = 0
                        backgroundNode.position = CGPoint(x: 100, y: 100)
                        wrongNode.text = "WRONG"
                        textNode.text = ""
                        
                        // Wait for 3 seconds using a DispatchQueue
                        DispatchQueue.main.asyncAfter(deadline: .now() + 5.5) { [self] in
                            // Set the text to an empty string
                            backgroundNode.position = CGPoint(x: -10000, y: -10000)
                            wrongNode.text = ""
                            textNode.text = "Play Cmaj Scale"
                        }
                        
                        
                        
                        let deathnoise = [
                            "mixkit-cartoon-laugh-voice-2882"
                        ]
                        
                        let deathnoisename = deathnoise[0]
                        let deathfile = deathnoise[0]
                        let deathURL = Bundle.main.url(forResource: deathfile, withExtension: "wav")
                        if deathfile == deathnoise[0] {
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) {
                                do {
                                    
                                    self.audioPlayer = try AVAudioPlayer(contentsOf: deathURL!)
                                    self.audioPlayer?.prepareToPlay()
                                    self.audioPlayer?.play()
                                } catch {
                                    print("Failed to play sound for node: \("the thing")")
                                }
                            }
                        }else {
                            print("Sound file not found for node: \("the thing")")
                        }
                        
                        sequenceIndex5 = 0
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) {
                            
                        }
                    }
                }
            }
            else if currentSequence == 6 {
                
                if let nodeName = result.node.name{
                    if nodeName == "box11" {
                        
                    }
                    
                    else if nodeName == result.node.name, nodeName == sequence6[sequenceIndex6]||nodeName == sequence6e[sequenceIndex6] {
                        // The user tapped the correct node in the sequence
                        sequenceIndex6 += 1
                        
                        if sequenceIndex6 >= sequence6.count {
                            // The user completed the sequence
                            textNode.text = ""
                            
                            
                            print("Sequence 6 complete!")
                            
                            
                            yesbackgroundNode.position = CGPoint(x: 100, y: 100)
                            correctNode.text = "CORRECT"
                            
                            // Wait for 3 seconds using a DispatchQueue
                            DispatchQueue.main.asyncAfter(deadline: .now() + 2) { [self] in
                                // Set the text to an empty string
                                correctNode.text = ""
                                yesbackgroundNode.position = CGPoint(x: -10000, y: -10000)
                                textNode.text = "Play C#minor Scale"
                            }
                            
                            
                            
                            
                            
                            
                            let woonoise = [
                                "woo-105117"
                            ]
                            let woonoisename = woonoise[0]
                            let woofile = woonoise[0]
                            let wooURL = Bundle.main.url(forResource: woofile, withExtension: "mp3")
                            
                            if woofile == woonoise[0] {
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) {
                                    
                                    do {
                                        self.audioPlayer = try AVAudioPlayer(contentsOf: wooURL!)
                                        self.audioPlayer?.prepareToPlay()
                                        self.audioPlayer?.play()
                                        
                                    }catch {
                                        print("Failed to play sound for node: \("the thing")")
                                    }
                                }
                            } else {
                                print("Sound file not found for node: \("the thing")")
                            }
                            
                            print(currentSequence)
                            sequenceIndex6 = 0  // Reset the sequence for the next round
                            currentSequence = 7
                            print(currentSequence)
                            
                        }
                    } else {
                        // The user tapped the wrong node or the sequence is not complete
                        print("Incorrect sequence!")
                        myCondition = true
                        // Set the initial text
                        sequenceIndex1 = 0
                        backgroundNode.position = CGPoint(x: 100, y: 100)
                        wrongNode.text = "WRONG"
                        textNode.text = ""
                        
                        // Wait for 3 seconds using a DispatchQueue
                        DispatchQueue.main.asyncAfter(deadline: .now() + 5.5) { [self] in
                            // Set the text to an empty string
                            backgroundNode.position = CGPoint(x: -10000, y: -10000)
                            wrongNode.text = ""
                            textNode.text = "Play the Aminor Scale"
                        }
                        
                        
                        
                        let deathnoise = [
                            "mixkit-cartoon-laugh-voice-2882"
                        ]
                        
                        let deathnoisename = deathnoise[0]
                        let deathfile = deathnoise[0]
                        let deathURL = Bundle.main.url(forResource: deathfile, withExtension: "wav")
                        if deathfile == deathnoise[0] {
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) {
                                do {
                                    
                                    self.audioPlayer = try AVAudioPlayer(contentsOf: deathURL!)
                                    self.audioPlayer?.prepareToPlay()
                                    self.audioPlayer?.play()
                                } catch {
                                    print("Failed to play sound for node: \("the thing")")
                                }
                            }
                        }else {
                            print("Sound file not found for node: \("the thing")")
                        }
                        
                        sequenceIndex6 = 0
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) {
                            
                        }
                    }
                }
            }
            else if currentSequence == 7 {
                
                if let nodeName = result.node.name{
                    if nodeName == "box11" {
                        
                    }
                    
                    else if nodeName == result.node.name, nodeName == sequence7[sequenceIndex7]||nodeName == sequence7e[sequenceIndex7] {
                        // The user tapped the correct node in the sequence
                        sequenceIndex7 += 1
                        
                        if sequenceIndex7 >= sequence7.count {
                            // The user completed the sequence
                            textNode.text = ""
                            
                            
                            print("Sequence 7 complete!")
                            
                            
                            yesbackgroundNode.position = CGPoint(x: 100, y: 100)
                            correctNode.text = "CORRECT"
                            
                            // Wait for 3 seconds using a DispatchQueue
                            DispatchQueue.main.asyncAfter(deadline: .now() + 2) { [self] in
                                // Set the text to an empty string
                                correctNode.text = ""
                                yesbackgroundNode.position = CGPoint(x: -10000, y: -10000)
                                textNode.text = "Play E Penatonic Scale"
                            }
                            
                            
                            
                            
                            
                            
                            let woonoise = [
                                "woo-105117"
                            ]
                            let woonoisename = woonoise[0]
                            let woofile = woonoise[0]
                            let wooURL = Bundle.main.url(forResource: woofile, withExtension: "mp3")
                            
                            if woofile == woonoise[0] {
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) {
                                    
                                    do {
                                        self.audioPlayer = try AVAudioPlayer(contentsOf: wooURL!)
                                        self.audioPlayer?.prepareToPlay()
                                        self.audioPlayer?.play()
                                        
                                    }catch {
                                        print("Failed to play sound for node: \("the thing")")
                                    }
                                }
                            } else {
                                print("Sound file not found for node: \("the thing")")
                            }
                            
                            print(currentSequence)
                            sequenceIndex7 = 0  // Reset the sequence for the next round
                            currentSequence = 8
                            print(currentSequence)
                            
                        }
                    } else {
                        // The user tapped the wrong node or the sequence is not complete
                        print("Incorrect sequence!")
                        myCondition = true
                        // Set the initial text
                        sequenceIndex7 = 0
                        backgroundNode.position = CGPoint(x: 100, y: 100)
                        wrongNode.text = "WRONG"
                        textNode.text = ""
                        
                        // Wait for 3 seconds using a DispatchQueue
                        DispatchQueue.main.asyncAfter(deadline: .now() + 5.5) { [self] in
                            // Set the text to an empty string
                            backgroundNode.position = CGPoint(x: -10000, y: -10000)
                            wrongNode.text = ""
                            textNode.text = "Play C# Minor Scale"
                        }
                        
                        
                        
                        let deathnoise = [
                            "mixkit-cartoon-laugh-voice-2882"
                        ]
                        
                        let deathnoisename = deathnoise[0]
                        let deathfile = deathnoise[0]
                        let deathURL = Bundle.main.url(forResource: deathfile, withExtension: "wav")
                        if deathfile == deathnoise[0] {
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) {
                                do {
                                    
                                    self.audioPlayer = try AVAudioPlayer(contentsOf: deathURL!)
                                    self.audioPlayer?.prepareToPlay()
                                    self.audioPlayer?.play()
                                } catch {
                                    print("Failed to play sound for node: \("the thing")")
                                }
                            }
                        }else {
                            print("Sound file not found for node: \("the thing")")
                        }
                        
                        sequenceIndex7 = 0
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) {
                            
                        }
                    }
                }
            }else if currentSequence == 8 {
                
                if let nodeName = result.node.name{
                    if nodeName == "box11" {
                        
                    }
                    
                    else if nodeName == result.node.name, nodeName == sequence8[sequenceIndex8]||nodeName == sequence8e[sequenceIndex8]  {
                        // The user tapped the correct node in the sequence
                        sequenceIndex8 += 1
                        
                        if sequenceIndex8 >= sequence8.count {
                            // The user completed the sequence
                            textNode.text = ""
                            
                            
                            print("Sequence 8 complete!")
                            
                            
                            yesbackgroundNode.position = CGPoint(x: 100, y: 100)
                            correctNode.text = "CORRECT"
                            
                            // Wait for 3 seconds using a DispatchQueue
                            DispatchQueue.main.asyncAfter(deadline: .now() + 2) { [self] in
                                // Set the text to an empty string
                                correctNode.text = ""
                                yesbackgroundNode.position = CGPoint(x: -10000, y: -10000)
                                textNode.text = "D# Locrian Scale"
                            }
                            
                            
                            
                            
                            
                            
                            let woonoise = [
                                "woo-105117"
                            ]
                            let woonoisename = woonoise[0]
                            let woofile = woonoise[0]
                            let wooURL = Bundle.main.url(forResource: woofile, withExtension: "mp3")
                            
                            if woofile == woonoise[0] {
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) {
                                    
                                    do {
                                        self.audioPlayer = try AVAudioPlayer(contentsOf: wooURL!)
                                        self.audioPlayer?.prepareToPlay()
                                        self.audioPlayer?.play()
                                        
                                    }catch {
                                        print("Failed to play sound for node: \("the thing")")
                                    }
                                }
                            } else {
                                print("Sound file not found for node: \("the thing")")
                            }
                            
                            print(currentSequence)
                            sequenceIndex8 = 0  // Reset the sequence for the next round
                            currentSequence = 9
                            print(currentSequence)
                            
                        }
                    } else {
                        // The user tapped the wrong node or the sequence is not complete
                        print("Incorrect sequence!")
                        myCondition = true
                        // Set the initial text
                        sequenceIndex8 = 0
                        backgroundNode.position = CGPoint(x: 100, y: 100)
                        wrongNode.text = "WRONG"
                        textNode.text = ""
                        
                        // Wait for 3 seconds using a DispatchQueue
                        DispatchQueue.main.asyncAfter(deadline: .now() + 5.5) { [self] in
                            // Set the text to an empty string
                            backgroundNode.position = CGPoint(x: -10000, y: -10000)
                            wrongNode.text = ""
                            textNode.text = "Play E Penatonic Scale"
                        }
                        
                        
                        
                        let deathnoise = [
                            "mixkit-cartoon-laugh-voice-2882"
                        ]
                        
                        let deathnoisename = deathnoise[0]
                        let deathfile = deathnoise[0]
                        let deathURL = Bundle.main.url(forResource: deathfile, withExtension: "wav")
                        if deathfile == deathnoise[0] {
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) {
                                do {
                                    
                                    self.audioPlayer = try AVAudioPlayer(contentsOf: deathURL!)
                                    self.audioPlayer?.prepareToPlay()
                                    self.audioPlayer?.play()
                                } catch {
                                    print("Failed to play sound for node: \("the thing")")
                                }
                            }
                        }else {
                            print("Sound file not found for node: \("the thing")")
                        }
                        
                        sequenceIndex8 = 0
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) {
                            
                        }
                    }
                }
            }
            else if currentSequence == 9 {
                
                if let nodeName = result.node.name{
                    if nodeName == "box11" {
                              
                            }
                    
                    else if nodeName == result.node.name, nodeName == sequence9[sequenceIndex9]||nodeName == sequence9e[sequenceIndex9] {
                    // The user tapped the correct node in the sequence
                    sequenceIndex9 += 1
                    
                    if sequenceIndex9 >= sequence9.count {
                        // The user completed the sequence
                        textNode.text = ""
                        
                        
                        print("Sequence 9 complete!")
                        
                        
                        yesbackgroundNode.position = CGPoint(x: 100, y: 100)
                        correctNode.text = "CORRECT"
                        
                        // Wait for 3 seconds using a DispatchQueue
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2) { [self] in
                            // Set the text to an empty string
                            correctNode.text = ""
                            yesbackgroundNode.position = CGPoint(x: -10000, y: -10000)
                            textNode.text = "Done!"
                        }
                        
                        
                        
                        
                        
                        
                        let woonoise = [
                            "woo-105117"
                        ]
                        let woonoisename = woonoise[0]
                        let woofile = woonoise[0]
                        let wooURL = Bundle.main.url(forResource: woofile, withExtension: "mp3")
                        
                        if woofile == woonoise[0] {
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) {
                                
                                do {
                                    self.audioPlayer = try AVAudioPlayer(contentsOf: wooURL!)
                                    self.audioPlayer?.prepareToPlay()
                                    self.audioPlayer?.play()
                                    
                                }catch {
                                    print("Failed to play sound for node: \("the thing")")
                                }
                            }
                        } else {
                            print("Sound file not found for node: \("the thing")")
                        }
                        
                        print(currentSequence)
                        sequenceIndex9 = 0  // Reset the sequence for the next round
                        currentSequence = 9
                        print(currentSequence)
                        
                    }
                } else {
                    // The user tapped the wrong node or the sequence is not complete
                    print("Incorrect sequence!")
                    myCondition = true
                    // Set the initial text
                    sequenceIndex9 = 0
                    backgroundNode.position = CGPoint(x: 100, y: 100)
                    wrongNode.text = "WRONG"
                    textNode.text = ""
                    
                    // Wait for 3 seconds using a DispatchQueue
                    DispatchQueue.main.asyncAfter(deadline: .now() + 5.5) { [self] in
                        // Set the text to an empty string
                        backgroundNode.position = CGPoint(x: -10000, y: -10000)
                        wrongNode.text = ""
                        textNode.text = "Play D# Locrian Scale"
                    }
                    
                    
                    
                    let deathnoise = [
                        "mixkit-cartoon-laugh-voice-2882"
                    ]
                    
                    let deathnoisename = deathnoise[0]
                    let deathfile = deathnoise[0]
                    let deathURL = Bundle.main.url(forResource: deathfile, withExtension: "wav")
                    if deathfile == deathnoise[0] {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) {
                            do {
                                
                                self.audioPlayer = try AVAudioPlayer(contentsOf: deathURL!)
                                self.audioPlayer?.prepareToPlay()
                                self.audioPlayer?.play()
                            } catch {
                                print("Failed to play sound for node: \("the thing")")
                            }
                        }
                    }else {
                        print("Sound file not found for node: \("the thing")")
                    }
                    
                    sequenceIndex9 = 0
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) {
                        
                    }
                }
            }
        }
            
            
            print(currentSequence)
            
        }
        
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.window?.becomeFirstResponder()
   
        
        
        
        
        print("_________________")
        print("_________________")
        print("_________________")
        print("_________________")
        print("_________________")
        print("_________________")
        print("_________________")
        let scene = SCNScene(named: "art.scnassets/ship.scn")!
        
        
        sceneView = SCNView(frame: view.bounds)
        sceneView.scene = scene
        sceneView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        view.addSubview(sceneView)
        
        if myCondition {
            let node1 = scene.rootNode.childNode(withName: "defaultMaterial-005", recursively: true)
            let node2 = scene.rootNode.childNode(withName: "defaultMaterial", recursively: true)
            
            // Define the nodes you want to unhide
            let nodesToUnhide: [SCNNode?] = [node1, node2]
            
            // Call the function to unhide the nodes for 20 seconds
          
        }
        
        
        // Create an SKScene with the same size as the SCNView
        let overlayScene = SKScene(size: sceneView.bounds.size)
        
        // Create an SKLabelNode with the desired text and add it to the overlay scene
        // Set the overlaySKScene property of the SCNView to the new SKScene
        sceneView.overlaySKScene = overlayScene
        // Disable camera control to prevent the user from moving the camera
        // Set the rendering order of the SCNView so the overlay is on top
        scene.rootNode.renderingOrder = 1
        if currentSequence == 1 {
            textNode.text = "Play C"
        }
        
        yesbackgroundNode.position = CGPoint(x: -10000, y: -10000)
        backgroundNode.position = CGPoint(x: -10000, y: -10000)
        textNode.position = CGPoint(x: overlayScene.size.width / 2, y: 660)
        textNode.fontSize = 90
        
        wrongNode.position = CGPoint(x: overlayScene.size.width / 2, y: 350)
        wrongNode.fontSize = 150
        wrongNode.fontName = "Helvetica-Bold"
        
        correctNode.position = CGPoint(x: overlayScene.size.width / 2, y: 350)
        correctNode.fontSize = 150
        correctNode.fontName = "Helvetica-Bold"
  
        
        
        imageNodeThing.position = CGPoint(x: 80 , y: 735)
        imageNodeThing.size = (CGSize(width: 53, height: 49))
        overlayScene.addChild(imageNodeThing)
        
      
        overlayScene.addChild(yesbackgroundNode)
        overlayScene.addChild(backgroundNode)
        overlayScene.addChild(textNode)
        overlayScene.addChild(wrongNode)
        overlayScene.addChild(correctNode)
        
        // Set the overlaySKScene property of the SCNView to the new SKScene
        sceneView.overlaySKScene = overlayScene
        // Disable camera control to prevent the user from moving the camera
        sceneView.allowsCameraControl = false
        
        // Set the rendering order of the SCNView so the overlay is on top
        scene.rootNode.renderingOrder = 2
        
        // Find the nodes you want to unhide
        //   if wronganswer == false {
        //                let node1 = scene.rootNode.childNode(withName: "defaultMaterial-005", recursively: true)
        //                let node2 = scene.rootNode.childNode(withName: "defaultMaterial", recursively: true)
        //
        //                // Define the nodes you want to unhide
        //                let nodesToUnhide: [SCNNode?] = [node1, node2]
        //
        //                // Call the function to unhide the nodes for 20 seconds
        //                unhideObjectsFor20Seconds(nodesToUnhide)
        // }
        
  
        
        if let skull = scene.rootNode.childNode(withName: "defaultMaterial-005", recursively: true) {
            // Get the material of the skull
            let materialSKULL = skull.geometry?.firstMaterial
            
            
            // Animate the emission of the material
            SCNTransaction.begin()
            SCNTransaction.animationDuration = 0.085
            
            // on completion - unhighlight
            SCNTransaction.completionBlock = {
                SCNTransaction.begin()
                SCNTransaction.animationDuration = 0.085
                
                materialSKULL?.emission.contents = UIColor.black
                
                SCNTransaction.commit()
            }
            
            let downAnimation = CABasicAnimation(keyPath: "position.z")
            downAnimation.fromValue = skull.position.z
            downAnimation.toValue = skull.position.z + 2.5
            downAnimation.repeatCount = .infinity
            downAnimation.autoreverses = true
            materialSKULL?.emission.contents = UIColor.black
            skull.addAnimation(downAnimation, forKey: "moveDown")
            //material.emission.contents = UIColor.red
            
            SCNTransaction.commit()
        } else {
            
        }
        
        let lightNode = SCNNode()
        lightNode.light = SCNLight()
        lightNode.light!.type = .omni
        lightNode.position = SCNVector3(x: 0, y: 10, z: 10)
        scene.rootNode.addChildNode(lightNode)
        
        
        let ambientLightNode = SCNNode()
        ambientLightNode.light = SCNLight()
        ambientLightNode.light!.type = .ambient
        ambientLightNode.light!.color = UIColor.darkGray
        scene.rootNode.addChildNode(ambientLightNode)
        
        
        let scnView = self.view as? SCNView
        
        
        scnView?.scene = scene
        
        
        scnView?.allowsCameraControl = false
        
        
        scnView?.showsStatistics = false
        
        
        scnView?.backgroundColor = UIColor.black
        
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        scnView?.addGestureRecognizer(tapGesture)
        
        
    }
    
    
    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        if UIDevice.current.userInterfaceIdiom == .phone {
            return .allButUpsideDown
        } else {
            return .all
        }
    }
    
}

class FreeViewController: UIViewController {
    
    
    
    let imageNodeThing = SKSpriteNode(imageNamed: "imageName")
  
    let buttonLabel = SKLabelNode(text: "")
    var sceneView: SCNView!

    var audioPlayer: AVAudioPlayer?
    
    
    
    @objc func HomeTapped() {
        print("hometapped")

        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)

                let nextViewController = storyBoard.instantiateViewController(withIdentifier: "homebutton") as! StartViewController

        nextViewController.modalPresentationStyle = .fullScreen
                self.present(nextViewController, animated:true, completion:nil)
    }
    
    
    
    @objc
    func handleTap(_ gestureRecognize: UIGestureRecognizer) {
        print("handling tap!!!")
        let scene = SCNScene(named: "art.scnassets/ship.scn")!
        let scnView = self.view as! SCNView
        let p = gestureRecognize.location(in: scnView)
        let hitResults = scnView.hitTest(p, options: [:])
        if hitResults.count > 0 {
            
            let result = hitResults[0]
            if let nodeName = result.node.name, !nodeName.isEmpty {
                
                let soundFiles = [
                    "Moog+Sub37-001": "C2.mp3",
                    "Moog+Sub37-002": "Db2.mp3",
                    "Moog+Sub37-003": "D2.mp3",
                    "Moog+Sub37-004": "Eb2.mp3",
                    "Moog+Sub37-005": "E2.mp3",
                    "Moog+Sub37-006": "F2.mp3",
                    "Moog+Sub37-007": "Gb2.mp3",
                    "Moog+Sub37-008": "G2.mp3",
                    "Moog+Sub37-009": "Ab2.mp3",
                    "Moog+Sub37-010": "A2.mp3",
                    "Moog+Sub37-011": "Bb2.mp3",
                    "Moog+Sub37-012": "B2.mp3",
                    "Moog+Sub37-013": "C3.mp3",
                    "Moog+Sub37-014": "Db3.mp3",
                    "Moog+Sub37-015": "D3.mp3",
                    "Moog+Sub37-016": "Eb3.mp3",
                    "Moog+Sub37-017": "E3.mp3",
                    "Moog+Sub37-018": "F3.mp3",
                    "Moog+Sub37-019": "Gb3.mp3",
                    "Moog+Sub37-020": "G3.mp3",
                    "Moog+Sub37-021": "Ab3.mp3",
                    "Moog+Sub37-022": "A3.mp3",
                    "Moog+Sub37-023": "Bb3.mp3",
                    "Moog+Sub37-024": "B3.mp3",
                    "Moog+Sub37-025": "C4.mp3",
                    "Moog+Sub37-026": "Db4.mp3",
                    "Moog+Sub37-027": "D4.mp3",
                    "Moog+Sub37-028": "Eb4.mp3",
                    "Moog+Sub37-029": "E4.mp3",
                    "Moog+Sub37-030": "F4.mp3",
                    "Moog+Sub37-031": "Gb4.mp3",
                    "Moog+Sub37-032": "G4.mp3",
                    "Moog+Sub37-033": "Ab4.mp3",
                    "Moog+Sub37-034": "A4.mp3",
                    "Moog+Sub37-035": "Bb4.mp3",
                    "Moog+Sub37-036": "B4.mp3",
                    "Moog+Sub37-037": "C5.mp3",
                    
                ]
                
                let soundFileName = soundFiles[nodeName] ?? ""
                if let soundFile = soundFiles[nodeName], let soundURL = Bundle.main.url(forResource: soundFile, withExtension: nil) {
                    do {
                        
                        audioPlayer = try AVAudioPlayer(contentsOf: soundURL)
                        audioPlayer?.prepareToPlay()
                        audioPlayer?.play()
                    } catch {
                        print("Failed to play sound for node: \(nodeName), error: \(error.localizedDescription)")
                    }
                } else {
                    print("Sound file not found for node: \(nodeName)")
                }
                
            }
            if let nodeName = result.node.name, nodeName == "box11"  {
                
                HomeTapped()
                let material = result.node.geometry!.firstMaterial!
                
                SCNTransaction.begin()
                SCNTransaction.animationDuration = 0.2
                SCNTransaction.completionBlock = {
                    SCNTransaction.begin()
                    SCNTransaction.animationDuration = 0.5
                    material.emission.contents = UIColor.black
                    let upAnimation = CABasicAnimation(keyPath: "position.y")
                    upAnimation.fromValue = result.node.position.y - 0.1
                    upAnimation.toValue = result.node.position.y
                    
                    result.node.addAnimation(upAnimation, forKey: "moveUp")
                    
                    
                    SCNTransaction.commit()
                }
                
                material.emission.contents = UIColor.red
                let downAnimation = CABasicAnimation(keyPath: "position.y")
                downAnimation.fromValue = result.node.position.y
                downAnimation.toValue = result.node.position.y - 1
                material.emission.contents = UIColor.black
                result.node.addAnimation(downAnimation, forKey: "moveDown")
                SCNTransaction.commit()
            }
            
            if let nodeName = result.node.name, nodeName == "Moog+Sub37-001" || nodeName == "Moog+Sub37-002" || nodeName == "Moog+Sub37-003" || nodeName == "Moog+Sub37-004" || nodeName == "Moog+Sub37-005" || nodeName == "Moog+Sub37-006" || nodeName == "Moog+Sub37-007" || nodeName == "Moog+Sub37-008" || nodeName == "Moog+Sub37-009" || nodeName == "Moog+Sub37-010" || nodeName == "Moog+Sub37-011" || nodeName == "Moog+Sub37-012" || nodeName == "Moog+Sub37-013" || nodeName == "Moog+Sub37-014" || nodeName == "Moog+Sub37-015" || nodeName == "Moog+Sub37-016" || nodeName == "Moog+Sub37-017" || nodeName == "Moog+Sub37-018" || nodeName == "Moog+Sub37-019" || nodeName == "Moog+Sub37-020" || nodeName == "Moog+Sub37-021" || nodeName == "Moog+Sub37-022" || nodeName == "Moog+Sub37-023" || nodeName == "Moog+Sub37-024" || nodeName == "Moog+Sub37-025" || nodeName == "Moog+Sub37-026" || nodeName == "Moog+Sub37-027" || nodeName == "Moog+Sub37-028" || nodeName == "Moog+Sub37-029" || nodeName == "Moog+Sub37-030" || nodeName == "Moog+Sub37-031" || nodeName == "Moog+Sub37-032" || nodeName == "Moog+Sub37-033" || nodeName == "Moog+Sub37-034" || nodeName == "Moog+Sub37-035" || nodeName == "Moog+Sub37-036" || nodeName == "Moog+Sub37-037"  {
                
                let material = result.node.geometry!.firstMaterial!
                
                SCNTransaction.begin()
                SCNTransaction.animationDuration = 0.2
                SCNTransaction.completionBlock = {
                    SCNTransaction.begin()
                    SCNTransaction.animationDuration = 0.5
                    material.emission.contents = UIColor.black
                    let upAnimation = CABasicAnimation(keyPath: "position.y")
                    upAnimation.fromValue = result.node.position.y - 0.1
                    upAnimation.toValue = result.node.position.y
                    
                    result.node.addAnimation(upAnimation, forKey: "moveUp")
                    
                    
                    SCNTransaction.commit()
                }
                
                material.emission.contents = UIColor.red
                let downAnimation = CABasicAnimation(keyPath: "position.y")
                downAnimation.fromValue = result.node.position.y
                downAnimation.toValue = result.node.position.y - 1
                material.emission.contents = UIColor.black
                result.node.addAnimation(downAnimation, forKey: "moveDown")
                SCNTransaction.commit()
            }
            
            
            
            
            
            
        }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let scene = SCNScene(named: "art.scnassets/ship.scn")!
        
        
        sceneView = SCNView(frame: view.bounds)
        sceneView.scene = scene
        sceneView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        view.addSubview(sceneView)
        
        
        
        let lightNode = SCNNode()
        lightNode.light = SCNLight()
        lightNode.light!.type = .omni
        lightNode.position = SCNVector3(x: 0, y: 10, z: 10)
        scene.rootNode.addChildNode(lightNode)
        
        
        let ambientLightNode = SCNNode()
        ambientLightNode.light = SCNLight()
        ambientLightNode.light!.type = .ambient
        ambientLightNode.light!.color = UIColor.darkGray
        scene.rootNode.addChildNode(ambientLightNode)
        
        
        if let ship = scene.rootNode.childNode(withName: "ship", recursively: true) {
            
        } else {
            
        }
        
        
        let scnView = self.view as? SCNView
        
        
        scnView?.scene = scene
        
        
        scnView?.allowsCameraControl = false
        
        
        scnView?.showsStatistics = false
        
        
        scnView?.backgroundColor = UIColor.black
        
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        scnView?.addGestureRecognizer(tapGesture)
        
        
        // Create an SKScene with the same size as the SCNView
        let overlayScene = SKScene(size: sceneView.bounds.size)
        // Create an SKLabelNode with the desired text and add it to the overlay scene
        // Set the overlaySKScene property of the SCNView to the new SKScene
        sceneView.overlaySKScene = overlayScene
        // Disable camera control to prevent the user from moving the camera
        // Set the rendering order of the SCNView so the overlay is on top
        scene.rootNode.renderingOrder = 1
   
      
       
       
    
    
        
        imageNodeThing.position = CGPoint(x: 80 , y: 735)
        imageNodeThing.size = (CGSize(width: 53, height: 49))
        overlayScene.addChild(imageNodeThing)
        

     
        
        // Set the overlaySKScene property of the SCNView to the new SKScene
        sceneView.overlaySKScene = overlayScene
        // Disable camera control to prevent the user from moving the camera
        sceneView.allowsCameraControl = false
        
        // Set the rendering order of the SCNView so the overlay is on top
        scene.rootNode.renderingOrder = 2
        
    }
    
    
    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        if UIDevice.current.userInterfaceIdiom == .phone {
            return .allButUpsideDown
        } else {
            return .all
        }
    }
    
}

//
//  StartViewController.swift
//  piano
//
//  Created by Andrew Suster on 5/16/23.
//
//
import AVFoundation
import UIKit
import QuartzCore
import SceneKit
import SwiftUI
import SpriteKit
class StartViewController: UIViewController {
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        

        let myView = UIView(frame: view.bounds)
     
//        view.addSubview(myView)
        
        
        
        let backgroundImage = UIImageView(frame: view.bounds)
            backgroundImage.image = UIImage(named: "startscreen") // Replace "yourImageName" with the actual name of your image file
        // backgroundImage.contentMode = .scaleAspectFit
            backgroundImage.contentMode = .scaleAspectFill
            view.addSubview(backgroundImage)
            view.sendSubviewToBack(backgroundImage)
        
    
        
        let button1 = UIButton(frame: CGRect(x: 0, y: 0, width: 235, height: 95))
        button1.center = CGPoint(x: 765, y: 398)
        button1.setTitle("", for: .normal)
        button1.backgroundColor = UIColor.blue
        button1.addTarget(self, action: #selector(buttonTapped1), for: .touchUpInside)
        myView.addSubview(button1)
       // button1.backgroundColor = UIColor.blue
        button1.backgroundColor = UIColor.blue.withAlphaComponent(0)
     
        
        let button2 = UIButton(frame: CGRect(x: 0, y: 0, width: 200, height: 95))
        button2.center = CGPoint(x: 410, y: 398)
        button2.setTitle("", for: .normal)
        button2.backgroundColor = UIColor.blue
        button2.addTarget(self, action: #selector(buttonTapped2), for: .touchUpInside)
        myView.addSubview(button2)
        //button2.backgroundColor = UIColor.blue
        button2.backgroundColor = UIColor.blue.withAlphaComponent(0)
        
        view.addSubview(myView)
    }
    
    @objc func buttonTapped1() {
        print("free play")

        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)

                let nextViewController = storyBoard.instantiateViewController(withIdentifier: "freeView") as! FreeViewController
        nextViewController.modalPresentationStyle = .fullScreen

                self.present(nextViewController, animated:true, completion:nil)
    }
    
    
    @objc func buttonTapped2() {
        print("skills test")
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)

                let nextViewController = storyBoard.instantiateViewController(withIdentifier: "gameView") as! GameViewController
        nextViewController.modalPresentationStyle = .fullScreen

                self.present(nextViewController, animated:true, completion:nil)
  
    }
    
    
    
    
}
